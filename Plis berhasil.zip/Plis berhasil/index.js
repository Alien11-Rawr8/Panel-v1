const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion
} = require("@whiskeysockets/baileys");

const fs = require("fs");
const Pino = require("pino");

// ====== CONFIG ======
const prefix = ".";
const ownerData = require("./config/owner.json");
const ownerNumber = ownerData.owner.map(v => v + "@s.whatsapp.net");

// ====== LIB ======
const isBanned = require("./lib/isBanned");
const { addPoint } = require("./lib/level");

// ====== AUTO CREATE DATABASE ======
const dbFiles = [
  "./database/users.json",
  "./database/level.json",
  "./database/banned.json",
  "./database/cooldown.json",
  "./database/donatur.json"
];

for (let file of dbFiles) {
  if (!fs.existsSync(file)) {
    fs.writeFileSync(file, file.includes(".json") ? "{}" : "[]");
  }
}

// ====== HELPER ======
const isOwner = (jid) => ownerNumber.includes(jid);

function getSender(msg) {
  return msg.key.fromMe
    ? sock.user.id
    : msg.key.participant || msg.key.remoteJid;
}

// ====== START BOT ======
async function startBot() {
  const { state, saveCreds } = await useMultiFileAuthState("session");
  const { version } = await fetchLatestBaileysVersion();

  sock = makeWASocket({
    version,
    auth: state,
    logger: Pino({ level: "silent" })
  });

  sock.ev.on("creds.update", saveCreds);

  // ====== CONNECTION ======
  sock.ev.on("connection.update", (update) => {
    const { connection, lastDisconnect } = update;
    if (connection === "close") {
      if (lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut) {
        startBot();
      }
    } else if (connection === "open") {
      console.log("🤖 Bot berhasil online");
    }
  });

  // ====== MESSAGE HANDLER ======
  sock.ev.on("messages.upsert", async ({ messages }) => {
    try {
      const msg = messages[0];
      if (!msg.message) return;
      if (msg.key.remoteJid === "status@broadcast") return;

      const sender = getSender(msg).replace(/@.+/, "");
      const from = msg.key.remoteJid;
      const isGroup = from.endsWith("@g.us");

      const body =
        msg.message.conversation ||
        msg.message.extendedTextMessage?.text ||
        msg.message.imageMessage?.caption ||
        "";

      if (!body.startsWith(prefix)) return;

      const args = body.slice(1).trim().split(/ +/);
      const command = args.shift().toLowerCase();

      // ====== BANNED CHECK ======
      if (isBanned(sender)) return;

      // ====== POINT AUTO (SETIAP CMD) ======
      addPoint(sender, 1);

      // ====== COMMAND SWITCH ======
      switch (command) {

        // ===== MENU =====
        case "menu":
          require("./commands/menu")(msg);
          break;

        case "rsmenu":
          require("./commands/rsmenu")(msg);
          break;

        // ===== LEVEL =====
        case "level":
          require("./commands/level")(msg, sender);
          break;

        case "lb":
          require("./commands/lb")(msg);
          break;

        // ===== ASK & REPORT =====
        case "ask":
          require("./commands/ask")(sock, msg, args, sender);
          break;

        case "report":
          require("./commands/report")(sock, msg, args, sender);
          break;

        // ===== PVC (OWNER) =====
        case "pvc":
          if (!isOwner(sender + "@s.whatsapp.net")) return;
          require("./commands/pvc")(sock, msg, args);
          break;

        // ===== GROUP CONTROL =====
        case "lock":
          require("./commands/lock")(sock, msg);
          break;

        case "unlock":
          require("./commands/unlock")(sock, msg);
          break;

        // ===== OWNER BAN =====
        case "ban":
          if (!isOwner(sender + "@s.whatsapp.net")) return;
          require("./commands/ban")(msg);
          break;

        case "unban":
          if (!isOwner(sender + "@s.whatsapp.net")) return;
          require("./commands/unban")(msg);
          break;

        // ===== DONATUR =====
        case "ldo":
          if (!isOwner(sender + "@s.whatsapp.net")) return;
          require("./commands/ldo")(msg, args);
          break;

        case "lbd":
          require("./commands/lbd")(msg);
          break;

        // ===== GAME =====
        case "tebak":
          require("./commands/tebak")(msg, args, sender);
          break;

        default:
          // command tidak dikenal
          break;
      }

    } catch (err) {
      console.error("ERROR:", err);
    }
  });
}

startBot();
