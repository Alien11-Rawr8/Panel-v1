module.exports = async (sock, msg) => {
  if (!msg.key.remoteJid.endsWith("@g.us"))
    return msg.reply("❌ Khusus group");

  let meta = await sock.groupMetadata(msg.key.remoteJid);
  let admins = meta.participants.filter(p => p.admin).map(p => p.id);

  if (!admins.includes(msg.key.participant))
    return msg.reply("❌ Admin only");

  await sock.groupSettingUpdate(
    msg.key.remoteJid,
    "announcement"
  );

  msg.reply("🔒 Group berhasil dikunci (admin only)");
};
