const fs = require("fs");

const rankName = {
  1: "Member",
  2: "Reseller",
  3: "VIP",
  4: "Owner"
};

module.exports = async (msg) => {
  const rankData = JSON.parse(fs.readFileSync("./config/rank.json"));

  let target;

  // jika reply chat orang lain
  if (msg.message.extendedTextMessage?.contextInfo?.participant) {
    target = msg.message.extendedTextMessage.contextInfo.participant
      .replace("@s.whatsapp.net", "");
  } else {
    // cek diri sendiri
    target = msg.key.remoteJid.replace("@s.whatsapp.net", "");
  }

  let rank = rankData[target] || 1;

  msg.reply(`
👤 *RANK INFO*

📱 Nomor: ${target}
🏷️ Rank: ${rankName[rank]} (${rank})
  `);
};
