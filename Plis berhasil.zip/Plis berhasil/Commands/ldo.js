const fs = require("fs");

module.exports = async (msg, args) => {
  let [nama, via, total] = args;
  if (!nama || !via || !total)
    return msg.reply("❌ .ldo nama via total");

  let path = "./database/donatur.json";
  let db = JSON.parse(fs.readFileSync(path));

  db.push({
    nama,
    via,
    total: Number(total),
    date: new Date().toLocaleDateString("id-ID")
  });

  fs.writeFileSync(path, JSON.stringify(db, null, 2));
  msg.reply("✅ Donatur ditambahkan");
};
