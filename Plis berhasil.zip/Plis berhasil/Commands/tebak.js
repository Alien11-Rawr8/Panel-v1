const { addPoint } = require("../lib/level");

module.exports = async (msg, args, sender) => {
  let pilih = Number(args[0]);
  if (![1,2,3,4,5].includes(pilih))
    return msg.reply("❌ Pilih angka 1–5\nContoh: .tebak 3");

  let bomb = Math.floor(Math.random()*5)+1;

  if (pilih === bomb) {
    addPoint(sender, -10);
    msg.reply(`💣 BOOM!\nAngka bom: ${bomb}\n❌ -10 Point`);
  } else {
    addPoint(sender, 10);
    msg.reply(`✅ AMAN!\nAngka bom: ${bomb}\n✨ +10 Point`);
  }
};
