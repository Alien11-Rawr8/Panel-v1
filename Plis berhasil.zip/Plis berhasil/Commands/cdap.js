const getRank = require("../lib/rank");
const genPass = require("../lib/password");
const getDate = require("../lib/date");

module.exports = async (msg, args, sender) => {
  if (getRank(sender) < 2) 
    return msg.reply("❌ Rank kamu tidak cukup");

  let name = args[0];
  let number = args[1];
  if (!name || !number)
    return msg.reply("❌ Contoh: .cadp Rexxy 0851xxxx");

  let pass = genPass(name);

  msg.reply(`
✅  *Succes Create ADP*

🌐 Link Panel:
https://cx.galaxyhost.biz.id

👤 Username: ${name}
🔐 Password: ${pass}
📅 Date: ${getDate()}
  `);
};
