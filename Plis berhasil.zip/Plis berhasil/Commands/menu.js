module.exports = async (msg) => {
  msg.sendImage("./media/menu1.jpg", `
📌 *MENU PANEL*
.cadp
.cuser
.chost
.ccom

© Credits: Rexxy
  `);
};
