const fs = require("fs");

module.exports = async (msg) => {
  if (!msg.message.extendedTextMessage?.contextInfo?.participant)
    return msg.reply("❌ Reply user yang mau di-unban");

  let target = msg.message.extendedTextMessage.contextInfo.participant
    .replace("@s.whatsapp.net", "");

  let path = "./database/banned.json";
  let db = JSON.parse(fs.readFileSync(path));

  if (!db.includes(target))
    return msg.reply("❌ User tidak diban");

  db = db.filter(n => n !== target);
  fs.writeFileSync(path, JSON.stringify(db, null, 2));

  msg.reply(`✅ User ${target} berhasil di-unban`);
};
