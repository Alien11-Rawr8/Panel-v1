const findUser = require("../lib/findUser");
const saveUser = require("../lib/saveUser");
const genPass = require("../lib/password");
const getDate = require("../lib/date");

module.exports = async (msg, args, sender) => {
  let usr = args[0];
  let host = args[1];

  if (!usr || !host)
    return msg.reply("❌ Contoh: .ccom Rexxy rexxy-host");

  // cek user harus ada
  let userData = findUser(usr);
  if (!userData)
    return msg.reply("❌ User belum ada, buat dulu dengan .cuser");

  let pass = genPass(usr);

  saveUser({
    type: "COMBO",
    username: usr,
    host: host,
    password: pass,
    created_by: sender,
    date: getDate()
  });

  msg.reply(`
✅ *Succes Create COMBO*

👤 User: ${usr}
🌐 Host: ${host}

🔐 Password: ${pass}

🔗 Link Panel:
https://p4.pablocloud.biz.id/

📅 Date: ${getDate()}
  `);
};
