module.exports = async (msg) => {
  msg.sendImage("./media/menu2.jpg", `
👑 *OWNER MENU*
.setrank
.delrank

🛒 Buy Script:
Klik tombol dibawah
  `, [
    {
      buttonId: "buy",
      buttonText: { displayText: "BUY SC" },
      type: 1
    }
  ]);
};
