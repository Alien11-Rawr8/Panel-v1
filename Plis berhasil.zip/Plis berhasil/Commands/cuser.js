const genPass = require("../lib/password");
const getDate = require("../lib/date");

module.exports = async (msg, args) => {
  let name = args[0];
  let number = args[1];
  if (!name || !number)
    return msg.reply("❌ Contoh: .cuser Rexxy 0851xxxx");

  msg.reply(`
✅  *Succes Create User*

🌐 Link Panel:
https://p4.pablocloud.biz.id/

👤 Username: ${name}
🔐 Password: ${genPass(name)}
📅 Date: ${getDate()}
  `);
};
