module.exports = async (sock, msg, args) => {
  if (msg.key.remoteJid.endsWith("@g.us"))
    return msg.reply("❌ Gunakan .pvc di private chat bot");

  if (args.length < 3)
    return msg.reply(
      "❌ Format salah\n.pvc (link) (dari) (pesan)"
    );

  let link = args[0];
  let dari = args[1];
  let pesan = args.slice(2).join(" ");

  let jid;

  // === PRIVATE CHAT (wa.me) ===
  if (link.includes("wa.me/")) {
    let number = link.split("wa.me/")[1].replace(/\D/g, "");
    jid = number + "@s.whatsapp.net";
  }

  // === GROUP CHAT ===
  else if (link.includes("chat.whatsapp.com/")) {
    let code = link.split("chat.whatsapp.com/")[1];
    jid = await sock.groupAcceptInvite(code);
  } else {
    return msg.reply("❌ Link WhatsApp tidak valid");
  }

  let text = `*${dari}*\n\n${pesan}`;

  await sock.sendMessage(jid, { text });

  msg.reply("✅ PVC berhasil dikirim sebagai BOT");
};
