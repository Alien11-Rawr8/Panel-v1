module.exports = async (msg) => {
  msg.reply(`
🧾 *RS MENU*

❓ .ask <pesan>
🚨 .report <pesan>

📊 .level
🏆 .lb
🎮 .tebak

© Rexxy
  `);
};
