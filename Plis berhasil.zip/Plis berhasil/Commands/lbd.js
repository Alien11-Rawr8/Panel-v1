const fs = require("fs");

module.exports = async (msg) => {
  let db = JSON.parse(fs.readFileSync("./database/donatur.json"));

  let list = db.sort((a,b)=>b.total-a.total).slice(0,10);
  if (!list.length) return msg.reply("❌ Belum ada donatur");

  let teks = "*💎 LEADERBOARD DONATUR*\n\n";
  list.forEach((d,i)=>{
    teks += `${i+1}. ${d.nama}\n💰 Rp${d.total}\nVia: ${d.via}\n\n`;
  });

  msg.reply(teks);
};
