const { getLevel } = require("../lib/level");

module.exports = async (msg, sender) => {
  let data = getLevel(sender);

  msg.reply(`
⭐ *LEVEL INFO*

🏅 Level: ${data.level}
✨ Point: ${data.point}/100
  `);
};
