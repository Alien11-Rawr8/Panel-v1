const fs = require("fs");

module.exports = async (msg) => {
  let db = JSON.parse(fs.readFileSync("./database/level.json"));

  let list = Object.entries(db)
    .sort((a, b) => b[1].level - a[1].level)
    .slice(0, 10);

  if (!list.length) return msg.reply("❌ Data kosong");

  let teks = "*🏆 LEADERBOARD LEVEL*\n\n";
  list.forEach((u, i) => {
    teks += `${i + 1}. ${u[0]}\n⭐ Level: ${u[1].level}\n✨ Point: ${u[1].point}\n\n`;
  });

  msg.reply(teks);
};
