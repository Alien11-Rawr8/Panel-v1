const { isCooldown } = require("../lib/cooldown");
const owner = require("../config/owner.json").owner;

module.exports = async (sock, msg, args, sender) => {
  if (!msg.key.remoteJid.endsWith("@g.us"))
    return msg.reply("❌ Report hanya bisa di group");

  let text = args.join(" ");
  if (!text) return msg.reply("❌ Tulis pesan report");

  let cd = isCooldown(sender, "report", 30);
  if (cd) return msg.reply(`⏳ Tunggu ${cd} detik`);

  let teks = `🚨 *REPORT MASUK*

👤 Pelapor: ${sender}
👥 Group: ${msg.key.remoteJid}

📢 ${text}`;

  for (let o of owner) {
    await sock.sendMessage(o + "@s.whatsapp.net", { text: teks });
  }

  msg.reply("✅ Report diteruskan ke owner");
};
