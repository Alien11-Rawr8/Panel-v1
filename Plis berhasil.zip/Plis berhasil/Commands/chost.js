const saveUser = require("../lib/saveUser");
const genPass = require("../lib/password");
const getDate = require("../lib/date");

module.exports = async (msg, args, sender) => {
  let usr = args[0];
  let os = args[1];

  if (!usr || !os)
    return msg.reply("❌ Contoh: .chost Rexxy linux / windows");

  os = os.toLowerCase();
  if (!["linux", "windows"].includes(os))
    return msg.reply("❌ OS hanya linux atau windows");

  let pass = genPass(usr);

  saveUser({
    type: "HOST",
    username: usr,
    os: os === "linux" ? "Linux" : "Windows",
    password: pass,
    created_by: sender,
    date: getDate()
  });

  msg.reply(`
✅ *Succes Create HOST*

👤 Username: ${usr}
🖥️ OS: ${os.toUpperCase()}
🔐 Password: ${pass}

🔗 Link Panel:
https://p4.pablocloud.biz.id/

📅 Date: ${getDate()}
  `);
};
