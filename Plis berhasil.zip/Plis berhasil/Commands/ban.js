const fs = require("fs");

module.exports = async (msg, args) => {
  if (!msg.message.extendedTextMessage?.contextInfo?.participant)
    return msg.reply("❌ Reply user yang mau diban");

  let target = msg.message.extendedTextMessage.contextInfo.participant
    .replace("@s.whatsapp.net", "");

  let db = JSON.parse(fs.readFileSync("./database/banned.json"));
  if (db.includes(target)) return msg.reply("❌ User sudah diban");

  db.push(target);
  fs.writeFileSync("./database/banned.json", JSON.stringify(db, null, 2));

  msg.reply(`⛔ User ${target} berhasil diban`);
};
