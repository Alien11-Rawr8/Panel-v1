module.exports = async (msg) => {
  await msg.reply("🧹 Chat dibersihkan");
};
